import "../components/navchild.css";
function Navchild() {
  return (
    <div className="Navchild">
      <div className="Navchild1">
        <p>Women Ethnic</p>
      </div>
      <div className="Navchild1">Women Western</div>
      <div className="Navchild1">Men</div>
      <div className="Navchild1">Kids</div>
      <div className="Navchild1">Home & Kitchen</div>
      <div className="Navchild1">Beauty & Health</div>
      <div className="Navchild1">Jewellery & Accessories</div>
      <div className="Navchild1">Bags & Footwear</div>
    </div>
  );
}
export default Navchild;
