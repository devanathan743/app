import Kidsproduct from "./kidsproducts";
import Mensproduct from "./Mensproduct";
import Womensproduct from "./Womensproducts";

function Dashboard() {
  return (
    <>
      <Mensproduct />
      <Womensproduct />
      <Kidsproduct />
    </>
  );
}
export default Dashboard;
